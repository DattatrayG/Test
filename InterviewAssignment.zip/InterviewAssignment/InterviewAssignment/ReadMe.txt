1. Download the project and unzip it.
2. Run the project using visual studio
3. Change the folder path under web config file. 
   Folder path is the path from where the application reads the text files.
4. Goes to the web config file path
   a.Open the files_Setting xml file from that path
   b.Set the File Name --> Your text File Name
     Set the Delimeter --> eg. , Or |
     Set the dateformat --> Date format of existing reading file
   c.You can Add Multiple file setting in this xml file
5.Keep your files in folder which path is set into the web config file.
6. Run the Application




