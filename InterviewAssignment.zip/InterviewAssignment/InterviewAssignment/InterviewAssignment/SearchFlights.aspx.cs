﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Runtime.Serialization;

namespace InterviewAssignment
{
    public partial class SearchFlights : System.Web.UI.Page
    {
        string folderPath = ConfigurationManager.AppSettings["FolderPath"];
        List<TextData> list = new List<TextData>();
        protected void Page_Load(object sender, EventArgs e)
        {
            Button1.Attributes.Add("onclick", "if(funValidation()==false) {return false;}");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Session["ViewFileData"] == null)
            {
            DataSet dsfiles = new DataSet();
            dsfiles.ReadXml(AppDomain.CurrentDomain.BaseDirectory + "\\files_Setting.xml");
            for (int i = 0; i < dsfiles.Tables[0].Rows.Count; i++)
            {
                if (File.Exists(folderPath + "\\" + dsfiles.Tables[0].Rows[i]["FileName"].ToString()))
                   UploadFileData(dsfiles.Tables[0].Rows[i]["FileName"].ToString(), dsfiles.Tables[0].Rows[i]["Delimeter"].ToString(), dsfiles.Tables[0].Rows[i]["DateFormat"].ToString(), ref  list);
            }
            list = list.GroupBy(x => new { x.Origin, x.Departure_Time, x.Destination, x.Destination_Time, x.Price })
                                .Select(g => g.First()).ToList();
            Session["ViewFileData"] = list;
            }
            else
            {
                list = (List<TextData>)Session["ViewFileData"];
            }

            list = list.Where(sr => sr.Origin.ToLower().Equals(txtSource.Text.ToLower().Trim()) && sr.Destination.ToLower().Equals(txtDestination.Text.ToLower().Trim()))
                        .OrderBy(g => g.Price).ThenBy(g => g.Departure_Time).ToList();
            lblResult.Text = "";
            if (list.Count == 0)
            {
                 lblResult.Text = "No Flights Found for " + txtSource.Text + "-->" + txtDestination.Text; 
            }
            else
            {
                foreach (TextData s in list)
                {
                    lblResult.Text += s.Origin + "-->" + s.Destination + "(" + s.Departure_Time.ToString("M/dd/yyyy H:mm:ss")
                                   + "-->" + s.Destination_Time.ToString("M/dd/yyyy H:mm:ss")
                                   + ") - $" + s.Price
                                   + "<br/>";
                }
            }
        }
        protected void UploadFileData(string filename, string delimeter, string dateformate, ref List<TextData> list)
        {
            using (StreamReader reader = new StreamReader(folderPath + "\\" + filename))
            {
                string line = reader.ReadLine();
                while ((line = reader.ReadLine()) != null)
                {
                    var data = line.Split(Convert.ToChar(delimeter));
                    TextData d = new TextData();
                    d.Origin = data[0];
                    d.Departure_Time = DateTime.ParseExact(data[1], dateformate, System.Globalization.CultureInfo.InvariantCulture);
                    d.Destination = data[2];
                    d.Destination_Time = DateTime.ParseExact(data[3], dateformate, System.Globalization.CultureInfo.InvariantCulture);
                    d.Price = Convert.ToDecimal(data[4].Replace("$", ""));
                    list.Add(d); // Add to list.
                }
            };
        }
        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSource.Text = string.Empty;
            txtDestination.Text = string.Empty;
            lblResult.Text = string.Empty;
            Session["ViewFileData"] = null;
        }
    }

}