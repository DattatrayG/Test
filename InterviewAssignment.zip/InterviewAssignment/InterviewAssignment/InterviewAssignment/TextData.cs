﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InterviewAssignment
{
    public class TextData
    {
        string _origin;

        public string Origin
        {
            get { return _origin; }
            set { _origin = value; }
        }
        DateTime _departure_Time;

        public DateTime Departure_Time
        {
            get { return _departure_Time; }
            set { _departure_Time = value; }
        }
        string _destination;

        public string Destination
        {
            get { return _destination; }
            set { _destination = value; }
        }

        DateTime _destination_Time;

        public DateTime Destination_Time
        {
            get { return _destination_Time; }
            set { _destination_Time = value; }
        }
        decimal _price;

        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }

    }
}